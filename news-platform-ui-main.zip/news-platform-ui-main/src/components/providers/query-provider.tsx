"use client";

import { type ReactNode } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/query-client";

interface QueryProviderProps {
   children: ReactNode;
}

export function QueryProvider({
   children,
}: QueryProviderProps): React.JSX.Element {
   return (
      <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
   );
}
